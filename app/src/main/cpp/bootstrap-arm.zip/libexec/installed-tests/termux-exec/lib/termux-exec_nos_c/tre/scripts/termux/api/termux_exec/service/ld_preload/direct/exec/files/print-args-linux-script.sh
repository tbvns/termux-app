#!/data/data/com.andronux.termux/files/usr/bin/sh

echo "$@"
